/*
 * Beat Repeat — tempo-synced stutter / repeat audio FX for Ableton Move (Schwung).
 *
 * Modeled on Ableton Live's Beat Repeat:
 *   Interval/Offset decide WHEN a capture is attempted (locked to Move's transport),
 *   Chance decides IF it happens, Grid sets the slice length, Gate how long the
 *   burst lasts, Decay/Pitch/Filter shape successive repeats, Mode sets how the
 *   dry signal behaves. Repeat (param or any MIDI note) stutters manually.
 *
 * Realtime notes: every entry point except create/destroy runs on the SPI audio
 * callback. No allocation, I/O or logging outside create/destroy.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include "host/plugin_api_v1.h"
#include "host/audio_fx_api_v2.h"

#define SR            44100.0
#define MIN_BPM       30.0
#define MAX_BPM       300.0
#define BUF_FRAMES    (2 * 44100 + 256)   /* longest slice: 1/4 note at 30 BPM = 2 s */
#define FADE_MAX      88                  /* ~2 ms slice edge fades */
#define GHOST_FADE    132                 /* ~3 ms crossfade when a burst restarts */

static const host_api_v1_t *g_host = NULL;

/* ---------- option tables ---------- */
static const char *GRID_NAMES[]   = { "1/4", "1/6", "1/8", "1/12", "1/16", "1/24", "1/32", "1/48", "1/64" };
static const double GRID_BEATS[]  = { 1.0, 2.0/3.0, 0.5, 1.0/3.0, 0.25, 1.0/6.0, 0.125, 1.0/12.0, 0.0625 };
#define N_GRID 9

static const char *INTV_NAMES[]   = { "1/4", "1/2", "1 Bar", "2 Bars", "4 Bars" };
static const double INTV_BEATS[]  = { 1.0, 2.0, 4.0, 8.0, 16.0 };
#define N_INTV 5

static const char *MODE_NAMES[]   = { "Mix", "Insert", "Gate" };
#define N_MODE 3
enum { MODE_MIX = 0, MODE_INSERT, MODE_GATE };

static const char *FILT_NAMES[]   = { "Off", "LP", "BP", "HP" };
#define N_FILT 4
enum { FILT_OFF = 0, FILT_LP, FILT_BP, FILT_HP };

static const char *ONOFF_NAMES[]  = { "Off", "On" };

/* ---------- instance ---------- */
typedef struct {
    float ic1[2], ic2[2];
} svf_t;

typedef struct {
    /* params */
    int    grid, interval, offset, gate, mode, filter, repeat;
    float  chance, variation, decay, pitch, pdecay, volume, freq;

    /* clock */
    double prev_beat;
    int    clock_valid;
    double free_beat;
    long long last_idx;

    /* burst state */
    int    active, stopping, manual;
    int    slice_len, rec_pos, t_in_slice, k, fade;
    long long gate_left;        /* samples; <0 = infinite (manual) */
    double play_pos, rate;
    float  rep_gain;

    /* ghost reader (crossfade out the previous burst on restart) */
    int    ghost_left;
    double ghost_pos, ghost_rate;
    float  ghost_gain;
    int    ghost_slice;

    /* smoothed gains */
    float  dry_g, wet_g;

    /* filter */
    svf_t  svf;
    float  f_g, f_k;

    /* manual trigger requests from set_param / MIDI */
    volatile int manual_req;    /* 1 = start, 0 = stop */
    int    midi_held;

    uint32_t rng;
    float  buf[BUF_FRAMES * 2];
} br_t;

/* ---------- helpers ---------- */
static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int   clampi(int v, int lo, int hi)       { return v < lo ? lo : (v > hi ? hi : v); }

static inline float rnd01(br_t *s) {
    uint32_t x = s->rng;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    s->rng = x;
    return (x >> 8) * (1.0f / 16777216.0f);
}

/* offset within the interval (avoids fmod, whose symbol is versioned past the Move's glibc) */
static inline double offset_beats(const br_t *s, double ib) {
    double o = s->offset * 0.25;
    while (o >= ib) o -= ib;
    return o;
}

static double current_bpm(void) {
    double b = 120.0;
    if (g_host && g_host->get_bpm) {
        float v = g_host->get_bpm();
        if (v > 1.0f) b = v;
    }
    if (b < MIN_BPM) b = MIN_BPM;
    if (b > MAX_BPM) b = MAX_BPM;
    return b;
}

static void update_filter(br_t *s) {
    /* freq 0..1 -> 40 Hz .. 18 kHz, log */
    double fc = 40.0 * pow(18000.0 / 40.0, s->freq);
    s->f_g = (float)tan(M_PI * fc / SR);
    s->f_k = (s->filter == FILT_BP) ? 0.7f : 1.2f;   /* BP a bit narrower */
}

static inline void svf_tick(br_t *s, int ch, float in, float *lp, float *bp, float *hp) {
    float g = s->f_g, k = s->f_k;
    float a1 = 1.0f / (1.0f + g * (g + k));
    float v3 = in - s->svf.ic2[ch];
    float v1 = a1 * s->svf.ic1[ch] + g * a1 * v3;
    float v2 = s->svf.ic2[ch] + g * v1;
    s->svf.ic1[ch] = 2.0f * v1 - s->svf.ic1[ch];
    s->svf.ic2[ch] = 2.0f * v2 - s->svf.ic2[ch];
    *lp = v2; *bp = v1; *hp = in - k * v1 - v2;
}

static inline void read_buf(const br_t *s, double pos, int len, float *l, float *r) {
    int i0 = (int)pos;
    float fr = (float)(pos - i0);
    if (i0 >= len) i0 = len - 1;
    int i1 = i0 + 1; if (i1 >= len) i1 = len - 1;
    const float *b = s->buf;
    *l = b[i0*2]   + (b[i1*2]   - b[i0*2])   * fr;
    *r = b[i0*2+1] + (b[i1*2+1] - b[i0*2+1]) * fr;
}

static inline float slice_env(int t, int len, int fade) {
    if (t < fade) return (float)t / fade;
    int rem = len - t;
    if (rem < fade) return (float)rem / fade;
    return 1.0f;
}

static void set_repeat_params(br_t *s) {
    /* gain and rate for repeat number k (k>=1) */
    s->rep_gain = powf(1.0f - s->decay, (float)(s->k - 1)) ;
    float semis = s->pitch * (1.0f + s->pdecay * 2.0f * (float)(s->k - 1));
    if (semis < -48.0f) semis = -48.0f;
    s->rate = pow(2.0, semis / 12.0);
}

static void start_burst(br_t *s, int manual) {
    /* crossfade the old burst out if it was audible */
    if (s->active && s->k >= 1) {
        s->ghost_left  = GHOST_FADE;
        s->ghost_pos   = s->play_pos;
        s->ghost_rate  = s->rate;
        s->ghost_gain  = s->rep_gain * s->volume;
        s->ghost_slice = s->slice_len;
    }

    int g = s->grid;
    if (s->variation > 0.0f) {
        float r = rnd01(s) * 2.0f - 1.0f;
        g = clampi(g + (int)lrintf(r * s->variation * 4.0f), 0, N_GRID - 1);
    }
    double bpm = current_bpm();
    int len = (int)(GRID_BEATS[g] * 60.0 / bpm * SR);
    s->slice_len  = clampi(len, 64, BUF_FRAMES);
    s->fade       = clampi(s->slice_len / 4, 8, FADE_MAX);
    s->rec_pos    = 0;
    s->t_in_slice = 0;
    s->k          = 0;
    s->play_pos   = 0.0;
    s->rate       = 1.0;
    s->rep_gain   = 1.0f;
    s->active     = 1;
    s->stopping   = 0;
    s->manual     = manual;
    s->gate_left  = manual ? -1 : (long long)(s->gate * 0.25 * 60.0 / bpm * SR);
}

static void stop_burst(br_t *s) {
    if (s->active) s->stopping = 1;
    s->manual = 0;
}

/* ---------- param plumbing ---------- */
static int parse_enum(const char *val, const char **names, int n) {
    for (int i = 0; i < n; i++)
        if (strcmp(val, names[i]) == 0) return i;
    char *end;
    double d = strtod(val, &end);
    if (end != val) return clampi((int)lrint(d), 0, n - 1);
    return -1;
}

static void apply_param(br_t *s, const char *key, const char *val) {
    int e;
    if      (!strcmp(key, "grid"))      { if ((e = parse_enum(val, GRID_NAMES, N_GRID)) >= 0) s->grid = e; }
    else if (!strcmp(key, "interval"))  { if ((e = parse_enum(val, INTV_NAMES, N_INTV)) >= 0) s->interval = e; }
    else if (!strcmp(key, "mode"))      { if ((e = parse_enum(val, MODE_NAMES, N_MODE)) >= 0) s->mode = e; }
    else if (!strcmp(key, "filter"))    { if ((e = parse_enum(val, FILT_NAMES, N_FILT)) >= 0) { s->filter = e; update_filter(s); } }
    else if (!strcmp(key, "repeat"))    {
        if ((e = parse_enum(val, ONOFF_NAMES, 2)) >= 0) { s->repeat = e; s->manual_req = e; }
    }
    else if (!strcmp(key, "offset"))    s->offset    = clampi((int)lrint(atof(val)), 0, 15);
    else if (!strcmp(key, "gate"))      s->gate      = clampi((int)lrint(atof(val)), 1, 64);
    else if (!strcmp(key, "chance"))    s->chance    = clampf(atof(val), 0, 1);
    else if (!strcmp(key, "variation")) s->variation = clampf(atof(val), 0, 1);
    else if (!strcmp(key, "decay"))     s->decay     = clampf(atof(val), 0, 1);
    else if (!strcmp(key, "pitch"))     s->pitch     = clampf(atof(val), -24, 0);
    else if (!strcmp(key, "pdecay"))    s->pdecay    = clampf(atof(val), 0, 1);
    else if (!strcmp(key, "volume"))    s->volume    = clampf(atof(val), 0, 1.5f);
    else if (!strcmp(key, "freq"))      { s->freq    = clampf(atof(val), 0, 1); update_filter(s); }
}

/* minimal JSON reader for "state": {"key":value,...} — values numeric or quoted */
static void apply_state(br_t *s, const char *json) {
    static const char *keys[] = { "grid","interval","offset","gate","mode","filter",
        "chance","variation","decay","pitch","pdecay","volume","freq" };
    for (unsigned i = 0; i < sizeof(keys)/sizeof(keys[0]); i++) {
        char pat[32];
        snprintf(pat, sizeof pat, "\"%s\"", keys[i]);
        const char *p = strstr(json, pat);
        if (!p) continue;
        p = strchr(p + strlen(pat), ':');
        if (!p) continue;
        p++;
        while (*p == ' ') p++;
        char v[32]; int n = 0;
        if (*p == '"') { p++; while (*p && *p != '"' && n < 31) v[n++] = *p++; }
        else           { while (*p && *p != ',' && *p != '}' && n < 31) v[n++] = *p++; }
        v[n] = 0;
        apply_param(s, keys[i], v);
    }
}

/* ---------- API ---------- */
static void *v2_create(const char *module_dir, const char *config_json) {
    br_t *s = (br_t *)calloc(1, sizeof(br_t));
    if (!s) return NULL;
    s->grid = 4;          /* 1/16 */
    s->interval = 2;      /* 1 bar */
    s->offset = 8;        /* hits on beat 3 */
    s->gate = 4;          /* one beat */
    s->mode = MODE_MIX;
    s->filter = FILT_OFF;
    s->chance = 1.0f;
    s->volume = 1.0f;
    s->freq = 0.6f;
    s->dry_g = 1.0f;
    s->rng = 0x9E3779B9u ^ (uint32_t)(uintptr_t)s;
    s->manual_req = -1;
    update_filter(s);
    if (config_json) apply_state(s, config_json);
    return s;
}

static void v2_destroy(void *inst) { free(inst); }

static void v2_process(void *inst, int16_t *io, int frames) {
    br_t *s = (br_t *)inst;
    if (!s) return;

    /* manual requests */
    if (s->manual_req == 1 && !s->manual)      start_burst(s, 1);
    else if (s->manual_req == 0 && s->manual)  stop_burst(s);
    s->manual_req = -1;

    /* clock for this block */
    double bpm = current_bpm();
    double db  = bpm / 60.0 / SR;
    double beat = -1.0;
    if (g_host && g_host->get_beat_position) beat = g_host->get_beat_position();
    if (beat < 0.0) {                       /* no transport: free-run */
        beat = s->free_beat;
        s->free_beat += db * frames;
        if (s->free_beat > 1e6) s->free_beat = 0.0;
    }
    if (!s->clock_valid || beat < s->prev_beat - 0.05 || beat > s->prev_beat + 2.0) {
        /* (re)sync — treat as if we were one sample earlier so a boundary at 'beat' fires */
        double ib = INTV_BEATS[s->interval], ob = offset_beats(s, ib);
        s->last_idx = (long long)floor((beat - db - ob) / ib);
        s->clock_valid = 1;
    }

    double ib = INTV_BEATS[s->interval];
    double ob = offset_beats(s, ib);
    const float sm = 0.0015f;               /* ~15 ms gain smoothing */

    for (int i = 0; i < frames; i++) {
        double b = beat + db * i;
        float inL = io[i*2]   * (1.0f / 32768.0f);
        float inR = io[i*2+1] * (1.0f / 32768.0f);

        /* trigger detection */
        long long idx = (long long)floor((b - ob) / ib);
        if (idx != s->last_idx) {
            s->last_idx = idx;
            if (!s->manual && s->chance > 0.0f && (s->chance >= 1.0f || rnd01(s) < s->chance))
                start_burst(s, 0);
        }

        float wL = 0.0f, wR = 0.0f;
        int   live = 0;

        if (s->active) {
            if (s->k == 0) {
                /* first slice: record, pass live */
                if (s->rec_pos < s->slice_len) {
                    s->buf[s->rec_pos*2]   = inL;
                    s->buf[s->rec_pos*2+1] = inR;
                    s->rec_pos++;
                }
                live = 1;
            } else {
                float l, r;
                read_buf(s, s->play_pos, s->slice_len, &l, &r);
                float env = slice_env(s->t_in_slice, s->slice_len, s->fade) * s->rep_gain * s->volume;
                wL = l * env; wR = r * env;
                s->play_pos += s->rate;
                if (s->play_pos > s->slice_len - 1) s->play_pos = s->slice_len - 1;
            }

            if (++s->t_in_slice >= s->slice_len) {
                s->t_in_slice = 0;
                s->play_pos = 0.0;
                s->k++;
                set_repeat_params(s);
                if (s->rep_gain * s->volume < 0.0005f && !s->manual) s->stopping = 1;
            }
            if (s->gate_left > 0 && --s->gate_left == 0) s->stopping = 1;
        }

        /* ghost (old burst) crossfade-out */
        if (s->ghost_left > 0) {
            float l, r;
            read_buf(s, s->ghost_pos, s->ghost_slice, &l, &r);
            float g = s->ghost_gain * (float)s->ghost_left / GHOST_FADE;
            wL += l * g; wR += r * g;
            s->ghost_pos += s->ghost_rate;
            if (s->ghost_pos > s->ghost_slice - 1) s->ghost_pos = s->ghost_slice - 1;
            s->ghost_left--;
        }

        /* filter on repeats */
        if (s->filter != FILT_OFF) {
            float lp, bp, hp;
            svf_tick(s, 0, wL, &lp, &bp, &hp);
            wL = s->filter == FILT_LP ? lp : s->filter == FILT_BP ? bp : hp;
            svf_tick(s, 1, wR, &lp, &bp, &hp);
            wR = s->filter == FILT_LP ? lp : s->filter == FILT_BP ? bp : hp;
        }

        /* gain targets */
        int repeating = s->active && !live && !s->stopping;
        float dry_t;
        switch (s->mode) {
            case MODE_INSERT: dry_t = repeating ? 0.0f : 1.0f; break;
            case MODE_GATE:   dry_t = (s->active && live && !s->stopping) ? 1.0f : 0.0f; break;
            default:          dry_t = 1.0f; break;
        }
        float wet_t = (s->active && !s->stopping) ? 1.0f : 0.0f;
        /* faster ramps so gate edges stay tight */
        s->dry_g += (dry_t - s->dry_g) * (sm * 4.0f);
        s->wet_g += (wet_t - s->wet_g) * (sm * 4.0f);

        if (s->stopping && s->wet_g < 0.0005f) { s->active = 0; s->stopping = 0; }

        float oL = inL * s->dry_g + wL * s->wet_g;
        float oR = inR * s->dry_g + wR * s->wet_g;

        int vL = (int)lrintf(oL * 32767.0f), vR = (int)lrintf(oR * 32767.0f);
        io[i*2]   = (int16_t)clampi(vL, -32768, 32767);
        io[i*2+1] = (int16_t)clampi(vR, -32768, 32767);
    }

    s->prev_beat = beat + db * frames;
}

static void v2_set_param(void *inst, const char *key, const char *val) {
    br_t *s = (br_t *)inst;
    if (!s || !key || !val) return;
    if (!strcmp(key, "state")) { apply_state(s, val); return; }
    apply_param(s, key, val);
}

static int v2_get_param(void *inst, const char *key, char *buf, int n) {
    br_t *s = (br_t *)inst;
    if (!s) return -1;
    if (!strcmp(key, "name"))      return snprintf(buf, n, "Beat Repeat");
    if (!strcmp(key, "grid"))      return snprintf(buf, n, "%s", GRID_NAMES[s->grid]);
    if (!strcmp(key, "interval"))  return snprintf(buf, n, "%s", INTV_NAMES[s->interval]);
    if (!strcmp(key, "mode"))      return snprintf(buf, n, "%s", MODE_NAMES[s->mode]);
    if (!strcmp(key, "filter"))    return snprintf(buf, n, "%s", FILT_NAMES[s->filter]);
    if (!strcmp(key, "repeat"))    return snprintf(buf, n, "%s", ONOFF_NAMES[s->repeat]);
    if (!strcmp(key, "offset"))    return snprintf(buf, n, "%d", s->offset);
    if (!strcmp(key, "gate"))      return snprintf(buf, n, "%d", s->gate);
    if (!strcmp(key, "chance"))    return snprintf(buf, n, "%.3f", s->chance);
    if (!strcmp(key, "variation")) return snprintf(buf, n, "%.3f", s->variation);
    if (!strcmp(key, "decay"))     return snprintf(buf, n, "%.3f", s->decay);
    if (!strcmp(key, "pitch"))     return snprintf(buf, n, "%.0f", s->pitch);
    if (!strcmp(key, "pdecay"))    return snprintf(buf, n, "%.3f", s->pdecay);
    if (!strcmp(key, "volume"))    return snprintf(buf, n, "%.3f", s->volume);
    if (!strcmp(key, "freq"))      return snprintf(buf, n, "%.3f", s->freq);
    if (!strcmp(key, "state"))
        return snprintf(buf, n,
            "{\"grid\":\"%s\",\"interval\":\"%s\",\"offset\":%d,\"gate\":%d,\"mode\":\"%s\","
            "\"filter\":\"%s\",\"chance\":%.4f,\"variation\":%.4f,\"decay\":%.4f,\"pitch\":%.0f,"
            "\"pdecay\":%.4f,\"volume\":%.4f,\"freq\":%.4f}",
            GRID_NAMES[s->grid], INTV_NAMES[s->interval], s->offset, s->gate, MODE_NAMES[s->mode],
            FILT_NAMES[s->filter], s->chance, s->variation, s->decay, s->pitch,
            s->pdecay, s->volume, s->freq);
    return -1;
}

static void v2_on_midi(void *inst, const uint8_t *msg, int len, int source) {
    br_t *s = (br_t *)inst;
    if (!s || len < 3) return;
    /* accept raw [status,d1,d2] or USB-MIDI [cin,status,d1,d2] */
    const uint8_t *m = msg;
    if (len >= 4 && (msg[1] & 0x80)) m = msg + 1;
    uint8_t st = m[0] & 0xF0;
    if (st == 0x90 && m[2] > 0)                       { s->midi_held++; s->manual_req = 1; }
    else if (st == 0x80 || (st == 0x90 && m[2] == 0)) {
        if (s->midi_held > 0) s->midi_held--;
        if (s->midi_held == 0 && !s->repeat) s->manual_req = 0;
    }
}

static audio_fx_api_v2_t g_api;

audio_fx_api_v2_t *move_audio_fx_init_v2(const host_api_v1_t *host) {
    g_host = host;
    memset(&g_api, 0, sizeof g_api);
    g_api.api_version      = AUDIO_FX_API_VERSION_2;
    g_api.create_instance  = v2_create;
    g_api.destroy_instance = v2_destroy;
    g_api.process_block    = v2_process;
    g_api.set_param        = v2_set_param;
    g_api.get_param        = v2_get_param;
    g_api.on_midi          = v2_on_midi;
    return &g_api;
}
