#!/usr/bin/env bash
# Build and copy straight onto a Move over SSH, then restart Move.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOST="${MOVE_HOST:-ableton@move.local}"
DEST=/data/UserData/schwung/modules/audio_fx/beat_repeat
"$ROOT/scripts/build.sh"
ssh "$HOST" "mkdir -p $DEST"
scp "$ROOT"/dist/beat_repeat/* "$HOST:$DEST/"
ssh "$HOST" /data/UserData/schwung/restart-move.sh || echo "Restart Move manually."
