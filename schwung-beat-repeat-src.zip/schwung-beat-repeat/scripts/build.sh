#!/usr/bin/env bash
# Cross-compile beat_repeat.so for Ableton Move (aarch64) and pack the module tarball.
# Uses aarch64-linux-gnu-gcc if present, otherwise builds inside Docker.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ID=beat_repeat
CC="${CROSS_PREFIX:-aarch64-linux-gnu-}gcc"
cd "$ROOT"

if ! command -v "$CC" >/dev/null 2>&1; then
  [ -n "${IN_DOCKER:-}" ] && { echo "no $CC in container" >&2; exit 1; }
  docker build -t beat-repeat-builder -f scripts/Dockerfile .
  exec docker run --rm -v "$ROOT:/work" -e IN_DOCKER=1 beat-repeat-builder ./scripts/build.sh
fi

OUT="dist/$ID"
rm -rf dist && mkdir -p "$OUT"
# No -ffast-math: avoids libmvec symbols the Move's glibc 2.35 doesn't ship.
"$CC" -O2 -fPIC -shared -Wall -Wno-unused-parameter -Isrc src/dsp/beat_repeat.c -o "$OUT/$ID.so" -lm
cp src/module.json help.json "$OUT/"
tar -C dist -czf "dist/$ID-module.tar.gz" "$ID"
echo "Built dist/$ID-module.tar.gz"
