# Beat Repeat for Ableton Move (Schwung)

Tempo-synced stutter/repeat audio FX, modeled on Live's Beat Repeat. Standard Schwung `audio_fx` chain module (API v2).

## Install

**Upload:** `move.local:7700` → Install Custom Module → upload `beat_repeat-module.tar.gz`.

**GitHub:** push this folder as a repo, attach `dist/beat_repeat-module.tar.gz` to a `v0.1.0` release, fix the URL in `release.json`, then Install Custom Module → `youruser/schwung-beat-repeat`.

**SSH (dev):** `MOVE_HOST=ableton@move.local scripts/deploy.sh`

Then load **Beat Repeat** into an FX slot of a Signal Chain.

## Controls

Main page (knobs 1–8):

| Knob | Param | Range |
|---|---|---|
| 1 | Grid — slice length | 1/4 … 1/64 incl. triplets |
| 2 | Interval — how often it tries | 1/4, 1/2, 1, 2, 4 bars |
| 3 | Chance | 0–100% |
| 4 | Gate — burst length | 1–64 sixteenths |
| 5 | Decay — each repeat quieter | 0–100% |
| 6 | Pitch — repeats resampled down | 0 to −24 st |
| 7 | Variation — random grid per burst | 0–100% |
| 8 | Volume of repeats | 0–150% |

More page: **Offset** (16ths into the interval, default 8 = beat 3), **Mode** (Mix / Insert / Gate), **Filter** (Off/LP/BP/HP) + **Freq** on repeats, **Pitch Decay** (pitch drops further each repeat), **Repeat** (manual hold).

Any MIDI note routed into the slot holds Repeat while pressed.

## Behaviour

- Locks to Move's transport via `get_beat_position`; when stopped it free-runs at the set tempo, so it still works on live input.
- First slice of each burst is the live signal (recorded as it passes), then the slice repeats — same as Live.
- Mix = dry + repeats. Insert = dry muted while repeating. Gate = only the bursts are heard.
- Slice edges get ~2 ms fades; a new burst crossfades out the previous one.
- Interval assumes 4/4.

## Build

```
scripts/build.sh          # uses aarch64-linux-gnu-gcc, else Docker
gcc -O2 -Isrc tests/render_test.c src/dsp/beat_repeat.c -lm -o rt && ./rt   # native test, writes WAVs
```

No `-ffast-math` and no `fmod` — both pull glibc symbols newer than the Move's 2.35.
