/* Native harness: fake host clock, feed a click/tone pattern, render a WAV, sanity-check. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "host/plugin_api_v1.h"
#include "host/audio_fx_api_v2.h"

audio_fx_api_v2_t *move_audio_fx_init_v2(const host_api_v1_t *host);

static double g_beat = 0.0;
static float  get_bpm(void) { return 120.0f; }
static double get_beat(void) { return g_beat; }

static void wav_hdr(FILE *f, int frames) {
    int data = frames * 4;
    fwrite("RIFF", 1, 4, f); int v = 36 + data; fwrite(&v, 4, 1, f);
    fwrite("WAVEfmt ", 1, 8, f); v = 16; fwrite(&v, 4, 1, f);
    short s = 1; fwrite(&s, 2, 1, f); s = 2; fwrite(&s, 2, 1, f);
    v = 44100; fwrite(&v, 4, 1, f); v = 44100 * 4; fwrite(&v, 4, 1, f);
    s = 4; fwrite(&s, 2, 1, f); s = 16; fwrite(&s, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&data, 4, 1, f);
}

static int run(const char *name, const char **kv, int nkv, int midi_at_block, int midi_off_block) {
    host_api_v1_t host; memset(&host, 0, sizeof host);
    host.sample_rate = 44100; host.frames_per_block = 128;
    host.get_bpm = get_bpm; host.get_beat_position = get_beat;
    audio_fx_api_v2_t *api = move_audio_fx_init_v2(&host);
    void *inst = api->create_instance(".", NULL);
    for (int i = 0; i < nkv; i += 2) api->set_param(inst, kv[i], kv[i + 1]);

    const int blocks = 44100 * 8 / 128;        /* 8 s = 4 bars @120 */
    int16_t io[256];
    char path[128]; snprintf(path, sizeof path, "out_%s.wav", name);
    FILE *f = fopen(path, "wb"); wav_hdr(f, blocks * 128);
    long n = 0; double peak = 0, diffmax = 0; int16_t prevL = 0; int bad = 0;
    double db = 120.0 / 60.0 / 44100.0;
    clock_t c0 = clock();
    for (int b = 0; b < blocks; b++) {
        g_beat = n * db;
        for (int i = 0; i < 128; i++, n++) {
            double t = n / 44100.0;
            double ph = fmod(t * 8.0, 1.0);    /* 16th-note pulses */
            double env = exp(-ph * 20.0);
            double x = 0.5 * env * sin(2 * M_PI * (220 + 110 * ((n / 5512) % 4)) * t);
            io[i * 2] = io[i * 2 + 1] = (int16_t)(x * 32767);
        }
        if (b == midi_at_block)  { uint8_t m[3] = {0x90, 60, 100}; api->on_midi(inst, m, 3, 2); }
        if (b == midi_off_block) { uint8_t m[3] = {0x80, 60, 0};   api->on_midi(inst, m, 3, 2); }
        api->process_block(inst, io, 128);
        for (int i = 0; i < 128; i++) {
            double a = fabs(io[i * 2] / 32768.0); if (a > peak) peak = a;
            double d = fabs((double)io[i * 2] - prevL); if (d > diffmax) diffmax = d; prevL = io[i * 2];
            if (abs(io[i * 2]) >= 32767) bad++;
        }
        fwrite(io, 2, 256, f);
    }
    double secs = (double)(clock() - c0) / CLOCKS_PER_SEC;
    fclose(f);
    char st[512]; api->get_param(inst, "state", st, sizeof st);
    printf("%-10s peak=%.3f maxstep=%.0f clipped=%d cpu=%.2f%%  state=%s\n",
           name, peak, diffmax, bad, 100.0 * secs / 8.0, st);
    api->destroy_instance(inst);
    return bad;
}

int main(void) {
    const char *a[] = { "grid", "1/32", "gate", "8", "decay", "0.2" };
    const char *b[] = { "mode", "Insert", "grid", "1/16", "pitch", "-7", "pdecay", "0.5", "filter", "LP", "freq", "0.4" };
    const char *c[] = { "mode", "Gate", "interval", "1/2", "offset", "0", "gate", "4", "variation", "1", "chance", "0.5" };
    const char *d[] = { "chance", "0", "grid", "3" /* index -> 1/12 */ };
    int bad = 0;
    bad += run("mix", a, 6, -1, -1);
    bad += run("insert", b, 12, -1, -1);
    bad += run("gate", c, 12, -1, -1);
    bad += run("manual", d, 4, 400, 900);
    return bad ? 1 : 0;
}
